/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;
import java.util.Scanner;
/**
 *
 * @author Student
 */
public class MainApp {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login login = new Login();
        
        // Display a header to indicate the start of the registration process
        System.out.println("============ USER REGISTRATION ===============");
        // Prompt the user to enter their first name and store the input
        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();
        // Prompt the user to enter their last name and store the input
        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();
        
        
        // --- USERNAME VALIDATION LOOP ---
        // Keep prompting the user until a valid username is entered.
        // A valid username must contain an underscore ('_') and be 5 characters or fewer.
        String username = "";
        String usernameMessage = "";
        while (!usernameMessage.equals("Username successfully captured.")) {
            System.out.print("Enter a username (must contain '_' and be <= 5 characters): ");
            username = input.nextLine();
            // Validate the entered username using the Login class
            // and store the resulting feedback message
            usernameMessage = login.validateUsername(username);
            System.out.println(usernameMessage);
        }
        
        // Password loop - validation handled by Login
        String password = "";
        String passwordMessage = "";
        while (!passwordMessage.equals("Password successfully captured.")) {
            System.out.print("Enter a password (8+ chars, 1 capital, 1 number, 1 special char): ");
            password = input.nextLine();
            passwordMessage = login.validatePassword(password);
            System.out.println(passwordMessage);
        }
        
        // Phone number loop - validation handled by Login
        String phoneNumber = "";
        String phoneMessage = "";
        while (!phoneMessage.equals("Cell phone number successfully added.")) {
            System.out.print("Enter your South African phone number (+27...): ");
            phoneNumber = input.nextLine();
            phoneMessage = login.validatePhoneNumber(phoneNumber);
            System.out.println(phoneMessage);
        }
        
        // Register and display result
        String registerMessage = login.registerUser(username, password, phoneNumber, firstName, lastName);
        System.out.println("\n" + registerMessage);
        
        
        
        // Login section
        if (registerMessage.equals("User registered successfully.")) {
            System.out.println("\n=== LOGIN ===");
            boolean loggedIn = false;
            while (!loggedIn) {
                System.out.print("Enter username: ");
                String loginUsername = input.nextLine();
                System.out.print("Enter password: ");
                String loginPassword = input.nextLine();
                loggedIn = login.loginUser(loginUsername, loginPassword);
                System.out.println(login.returnLoginStatus(loggedIn));
            }
        } else {
            System.out.println("Registration failed. Please restart and try again.");
        }
        
        input.close();
    }
    
    /**
     * Handles the full registration flow: prompts for first name, last name,
     * username, password, and phone number, then registers the user.
     *
     * @param input the Scanner used for reading user input
     * @param login the Login instance used for validation and registration
     * @return the registration result message from Login
     */
    public static String runRegistration(Scanner input, Login login) {
        System.out.println("============ USER REGISTRATION ===============");

        System.out.print("Enter your first name: ");
        String firstName = input.nextLine();

        System.out.print("Enter your last name: ");
        String lastName = input.nextLine();

        String username = "";
        String usernameMessage = "";
        while (!usernameMessage.equals("Username successfully captured.")) {
            System.out.print("Enter a username (must contain '_' and be <= 5 characters): ");
            username = input.nextLine();
            usernameMessage = login.validateUsername(username);
            System.out.println(usernameMessage);
        }

        String password = "";
        String passwordMessage = "";
        while (!passwordMessage.equals("Password successfully captured.")) {
            System.out.print("Enter a password (8+ chars, 1 capital, 1 number, 1 special char): ");
            password = input.nextLine();
            passwordMessage = login.validatePassword(password);
            System.out.println(passwordMessage);
        }

        String phoneNumber = "";
        String phoneMessage = "";
        while (!phoneMessage.equals("Cell phone number successfully added.")) {
            System.out.print("Enter your South African phone number (+27...): ");
            phoneNumber = input.nextLine();
            phoneMessage = login.validatePhoneNumber(phoneNumber);
            System.out.println(phoneMessage);
        }

        String registerMessage = login.registerUser(username, password, phoneNumber, firstName, lastName);
        System.out.println("\n" + registerMessage);
        return registerMessage;
    }

    /**
     * Handles the login flow: repeatedly prompts for username and password
     * until a successful login is achieved.
     *
     * @param input the Scanner used for reading user input
     * @param login the Login instance used for authentication
     */
    public static void runLogin(Scanner input, Login login) {
        System.out.println("\n=== LOGIN ===");
        boolean loggedIn = false;
        while (!loggedIn) {
            System.out.print("Enter username: ");
            String loginUsername = input.nextLine();
            System.out.print("Enter password: ");
            String loginPassword = input.nextLine();
            loggedIn = login.loginUser(loginUsername, loginPassword);
            System.out.println(login.returnLoginStatus(loggedIn));
        }
    }
    
}